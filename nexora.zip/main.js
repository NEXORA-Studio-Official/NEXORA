var messages = {
            game: JSON.parse(localStorage.getItem('messages-game')) || [],
            bugs: JSON.parse(localStorage.getItem('messages-bugs')) || [],
            updates: JSON.parse(localStorage.getItem('messages-updates')) || []
        };
        function showPage(pageId) {
            window.scrollTo(0, 0);
            if(pageId === 'proxy' || pageId === 'settings') {
                document.body.classList.add('no-scroll');
            } else {
                document.body.classList.remove('no-scroll');
            }
            var stack = document.getElementById('notification-stack');
            if(stack) stack.innerHTML = '';
            for(var k in notificationTimers) {
                if(notificationTimers[k]) clearTimeout(notificationTimers[k]);
                notificationTimers[k] = null;
            }
            var titles = {
                'home': 'HOME',
                'games': 'GAMES',
                'request-game': 'REQUEST A GAME',
                'request-bugs': 'REPORT A BUG',
                'request-updates': 'REQUEST A FUTURE UPDATE',
                'proxy': 'PROXY',
                'settings': 'SETTINGS',
                'credits': 'CREDITS'
            };
            var pageTitle = titles[pageId] || 'NEXORA';
            document.title = pageTitle === 'NEXORA' ? 'NEXORA' : ('NEXORA - ' + pageTitle);
            var pages = document.querySelectorAll('.page');
            for(var i = 0; i < pages.length; i++) {
                pages[i].classList.remove('active');
            }
            document.getElementById(pageId).classList.add('active');
            if(pageId === 'request-game' || pageId === 'request-bugs' || pageId === 'request-updates') {
                var type = pageId.replace('request-', '');
                displayMessages(type);
            }
        }
        function submitMessage(type) {
            var messageInput = document.getElementById('message-' + type);
            var messageText = messageInput.value.trim();
            var pageName = '';
            var emptyMessage = '';
            if(type === 'game') { pageName = 'game request'; emptyMessage = 'PLEASE TYPE YOUR GAME REQUEST IN THE BOX DOWN BELOW<br>ERROR NUMBER 2'; }
            else if(type === 'bugs') { pageName = 'bug report'; emptyMessage = 'PLEASE TYPE YOUR BUG REPORT IN THE BOX DOWN BELOW<br>ERROR NUMBER 2'; }
            else if(type === 'updates') { pageName = 'future update request'; emptyMessage = 'PLEASE TYPE YOUR FUTURE UPDATE REQUEST IN THE BOX DOWN BELOW<br>ERROR NUMBER 2'; }
            if(!messageText) {
                showNotification(emptyMessage, type);
                return;
            }
            (function(){
                var failureLabel = 'FAILURE TO SUBMIT REQUEST';
                var contactLine = 'Please contact The.NEXORA.Team@outlook.com about your ' + pageName + '.';
                if(type === 'bugs') {
                    failureLabel = 'FAILURE TO SUBMIT BUG REPORT';
                    contactLine = 'Please contact The.NEXORA.Team@outlook.com to report the bug you found.';
                } else if(type === 'game') {
                    failureLabel = 'FAILURE TO SUBMIT GAME REQUEST';
                    contactLine = 'Please contact The.NEXORA.Team@outlook.com to request a game.';
                } else if(type === 'updates') {
                    failureLabel = 'FAILURE TO SUBMIT FUTURE UPDATE REQUEST';
                    contactLine = 'Please contact The.NEXORA.Team@outlook.com to request a future update.';
                }
                showNotification(failureLabel + '<br>ERROR NUMBER 1<br><br>' + contactLine, type);
            })();
        }
        function formatTimestamp(date) {
            var options = {
                year: 'numeric',
                month: 'numeric',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
                hour12: true
            };
            return date.toLocaleString('en-US', options);
        }
        function displayMessages(type) {
            var container = document.getElementById('messages-' + type);
            if(messages[type].length === 0) {
                container.innerHTML = '<p class="no-messages">No requests submitted yet.</p>';
                return;
            }
            var html = '';
            for(var i = messages[type].length - 1; i >= 0; i--) {
                var msg = messages[type][i];
                html += '<div class="message-card" data-id="' + msg.id + '">';
                html += '<div class="message-header">';
                html += '<span class="message-name">' + msg.name + '</span>';
                html += '<span class="message-time">' + msg.timestamp + '</span>';
                html += '</div>';
                html += '<div class="message-content">';
                html += '<div class="message-text">' + msg.text + '</div>';
                html += '</div>';
                html += '</div>';
            }
            container.innerHTML = html;
        }
        var notificationTimers = {};
        var notificationCount = 0;
        function clearNotifications() {
            var stack = document.getElementById('notification-stack');
            if(stack) stack.innerHTML = '';
            for(var k in notificationTimers) {
                if(notificationTimers[k]) clearTimeout(notificationTimers[k]);
                notificationTimers[k] = null;
            }
        }
        function showNotification(message, kind) {
            var stack = document.getElementById('notification-stack');
            if(!stack) {
                stack = document.createElement('div');
                stack.id = 'notification-stack';
                stack.className = 'notification-stack';
                document.body.appendChild(stack);
            }
            clearNotifications();
            notificationCount += 1;
            var id = 'notification-' + Date.now() + '-' + notificationCount;
            var el = document.createElement('div');
            el.id = id;
            el.className = 'notification ' + (kind || 'error');
            el.innerHTML = message;
            stack.appendChild(el);
            notificationTimers[id] = setTimeout(function() {
                if(el && el.parentNode) el.parentNode.removeChild(el);
                notificationTimers[id] = null;
            }, 3000);
        }
        function searchProxy() {
            
            var searchInput = document.getElementById('proxy-search');
            if (!searchInput) return;
            var searchQuery = (searchInput.value || '').trim();
            if (!searchQuery) return;

            var url = searchQuery;
            
            if (!/^https?:\/\
                if (url.indexOf('.') > -1) {
                    url = 'https:
                } else {
                    
                    url = 'https:
                }
            }

            var iframe = document.getElementById('proxy-iframe');
            var frameContainer = document.getElementById('proxy-frame-container');
            if (!iframe || !frameContainer) return;
            iframe.src = url;
            frameContainer.style.display = 'block';
            searchInput.value = '';
        }
        
        var pendingGame = null;
        function openGame(gameName) {
            clearNotifications();
            
            var spaceBarGames = ['tetris','breakout','pong'];
            
            if (spaceBarGames.indexOf(gameName) !== -1) {
                pendingGame = gameName;
                var modal = document.getElementById('space-warning-modal');
                modal.classList.add('active');
                return;
            }
            loadGame(gameName);
        }
        
        function cancelGameWarning() {
            var modal = document.getElementById('space-warning-modal');
            modal.classList.remove('active');
            pendingGame = null;
        }
        
        function continueToGame() {
            var modal = document.getElementById('space-warning-modal');
            modal.classList.remove('active');
            if (pendingGame) {
                loadGame(pendingGame);
                pendingGame = null;
            }
        }
        
        function loadGame(gameName) {
            var fullscreenContainer = document.getElementById('fullscreen-game');
            var gameIframe = document.getElementById('game-iframe');
                        gameIframe.classList.toggle('tetris-centered', gameName === 'tetris');
var gameTitleElement = document.getElementById('game-title-fullscreen');
            var gameLoader = document.getElementById('game-loader');
            var loaderBar = document.getElementById('loader-bar');
            var loaderPercent = document.getElementById('loader-percent');
            var games = {
                '2048': { title: '2048', src: '2048/index.html' },
                'tetris': { title: 'TETRIS', src: 'tetris/index.html' },
                'breakout': { title: 'BREAKOUT', src: 'breakout/index.html' },
                'wordle': { title: 'WORDLE', src: 'wordle/index.html' },
                'pong': { title: 'PONG', src: 'pong/index.html' },
                'solitaire': { title: 'SOLITAIRE', src: 'solitaire/index.html' },
                'flappybird': { title: 'FLAPPY BIRD', src: 'flappybird/index.html' }};
            if (games[gameName]) {
                gameIframe.src = '';
                gameIframe.style.display = 'none';
                loaderBar.style.width = '0%';
                loaderPercent.textContent = '0%';
                gameTitleElement.textContent = games[gameName].title;
                gameLoader.classList.remove('hidden');
                fullscreenContainer.classList.add('active');
                document.body.style.overflow = 'hidden';
                var progress = 0;
                var interval = setInterval(function() {
                    progress += Math.random() * 15;
                    if (progress > 100) progress = 100;
                    loaderBar.style.width = progress + '%';
                    loaderPercent.textContent = Math.floor(progress) + '%';
                    if (progress >= 100) {
                        clearInterval(interval);
                        setTimeout(function() {
                            gameLoader.classList.add('hidden');
                            gameIframe.style.display = 'block';
                            gameIframe.src = games[gameName].src;
                        }, 200);
                    }
                }, 100);
                return;
            }
            showNotification('NO GAMES AVAILABLE RIGHT NOW<br>ERROR NUMBER 1', 'game');
        }
        function openExternalGame(url) {
            window.open(url, '_blank');
        }
        function closeGame() {
            var fullscreenContainer = document.getElementById('fullscreen-game');
            var gameIframe = document.getElementById('game-iframe');
            var gameLoader = document.getElementById('game-loader');
            var loaderBar = document.getElementById('loader-bar');
            var loaderPercent = document.getElementById('loader-percent');
            fullscreenContainer.classList.remove('active');
            gameIframe.src = '';
            document.body.style.overflow = 'auto';
            gameLoader.classList.add('hidden');
            gameIframe.style.display = 'none';
            loaderBar.style.width = '0%';
            loaderPercent.textContent = '0%';
        }
        window.addEventListener('blur', clearNotifications);
        document.addEventListener('visibilitychange', function() {
            if(document.hidden) clearNotifications();
        });
        window.onload = function() {
            displayMessages('game');
            displayMessages('bugs');
            displayMessages('updates');
            var gameSearch = document.getElementById('game-search');
            if (gameSearch) {
                gameSearch.addEventListener('input', function () {var q = gameSearch.value.trim().toLowerCase();var cards = document.querySelectorAll('#games .game-card');var anyVisible = false;cards.forEach(function (card) {var title = (card.getAttribute('data-title') || '').toLowerCase();var show = !q || title.indexOf(q) !== -1;card.style.display = show ? '' : 'none';if (show) anyVisible = true;});var msg = document.getElementById('no-game-results');if (msg) {msg.style.display = (!q || anyVisible) ? 'none' : '';}});
            }

            var gameIframe = document.getElementById('game-iframe');
            if (gameIframe) {
                gameIframe.onload = function() {
                    try {
                        var doc = gameIframe.contentDocument || (gameIframe.contentWindow && gameIframe.contentWindow.document);
                        if (doc && doc.head) {
                            var style = doc.createElement('style');
                            style.textContent = 'html,body{margin:0;padding:0;overflow:auto;}img,canvas,svg,video{max-width:100%;height:auto;}iframe{border:0;}';
                            doc.head.appendChild(style);
}
                    } catch (err) {}
                };
            }
            var searchInput = document.getElementById('proxy-search');
            searchInput.onkeypress = function(e) {
                if(e.key === 'Enter') {
                    e.preventDefault();
                    searchProxy();
                }
            };
        };
    